## Project Summary
This project is a high-fidelity clone of the American Red Cross Blood Donor App landing page. It features a professional, medical-themed design with bold red accents, clear calls to action, and interactive components like a testimonial carousel and a cookie consent banner.

## Tech Stack
- Framework: Next.js (App Router)
- Language: TypeScript
- Styling: Tailwind CSS
- Icons: Lucide React
- Components: Custom React components (cloned from original site)

## Architecture
- `src/app/`: Contains the main page and layout.
- `src/components/sections/`: Modularized sections of the landing page for better maintainability.
- `src/app/globals.css`: Contains the theme variables and base styles derived from the Red Cross branding.

## User Preferences
- Follows the official American Red Cross design language.

## Project Guidelines
- Maintain high accessibility and professional aesthetic.
- Use the provided theme variables for consistency.

## Common Patterns
- Modular component-based architecture for landing page sections.
- Responsive design using Tailwind CSS utility classes.
