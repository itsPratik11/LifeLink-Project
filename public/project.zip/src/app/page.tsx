import Header from "@/components/sections/header";
import EmergencyBanner from "@/components/sections/emergency-banner";
import HeroSection from "@/components/sections/hero";
import AppFeatures from "@/components/sections/app-features";
import CtaMidpage from "@/components/sections/cta-midpage";
import Testimonials from "@/components/sections/testimonials";
import FooterApps from "@/components/sections/footer-apps";
import CookieConsent from "@/components/sections/cookie-consent";

export default function Home() {
  return (
    <div className="flex flex-col min-h-screen">
      <Header />
      <main className="flex-1">
        <EmergencyBanner />
        <HeroSection />
        <AppFeatures />
        <CtaMidpage />
        <Testimonials />
        <FooterApps />
      </main>
      <CookieConsent />
    </div>
  );
}
