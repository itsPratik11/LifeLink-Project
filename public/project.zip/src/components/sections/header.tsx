import React from 'react';
import Image from 'next/image';
import { Search, ChevronRight } from 'lucide-react';

/**
 * Header Component
 * 
 * Clones the American Red Cross global navigation including:
 * - Utility navigation (top)
 * - Main navigation with dropdown capabilities
 * - Brand logo
 * - "Find a Blood Drive" search widget
 */
const Header = () => {
  return (
    <header id="rcb-header" className="relative w-full z-[1000] bg-white">
      {/* Subtle top gradient shadow as seen index.html style */}
      <div className="absolute top-0 left-0 w-full h-[3px] bg-gradient-to-b from-black/5 to-transparent"></div>

      {/* Utility Navigation Bar (Top) */}
      <div className="border-b border-[#e5e5e5] bg-[#f7f7f7] py-2 hidden lg:block">
        <div className="max-w-[1230px] mx-auto px-[15px] flex justify-end items-center text-[12px] font-semibold text-[#333333]">
          <div className="flex items-center space-x-4">
            <button className="flex items-center hover:text-[#ed1b2e] transition-colors">
              <Search className="w-3.5 h-3.5 mr-1" />
              <span className="sr-only">Search</span>
            </button>
            <div className="flex items-center space-x-1.5 before:content-['•'] before:text-[#666] before:mr-1.5">
              <a href="/account-login.html" className="text-[#ed1b2e] font-bold uppercase tracking-tight">Sign In</a>
            </div>
            <div className="flex items-center space-x-1.5 before:content-['•'] before:text-[#666] before:mr-1.5">
              <a href="/espanol/donar-sangre.html" className="hover:underline">Español</a>
            </div>
            <div className="flex items-center space-x-1.5 before:content-['•'] before:text-[#666] before:mr-1.5">
              <a href="/local-homepage.html" className="hover:underline">News & Promotions</a>
            </div>
            <div className="flex items-center space-x-1.5 before:content-['•'] before:text-[#666] before:mr-1.5">
              <a href="http://www.redcross.org" className="hover:underline">Visit RedCross.org</a>
            </div>
          </div>
        </div>
      </div>

      {/* Main Navigation Header */}
      <div className="max-w-[1230px] mx-auto px-[15px] flex items-stretch justify-between h-[80px]">
        {/* Logo Section */}
        <div className="flex items-center py-4">
          <a href="/" className="block min-w-[200px]">
            <Image 
              src="https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/97b90385-8109-40fe-958d-b72a3833b6a8-redcrossblood-org/assets/images/arc-logo_copy-10.png"
              alt="American Red Cross Blood Services Logos"
              width={230}
              height={50}
              className="object-contain"
              priority
            />
          </a>
        </div>

        {/* Desktop Main Nav */}
        <nav className="hidden lg:flex flex-1 justify-center items-stretch">
          <ul className="flex items-stretch mx-8">
            <li className="group relative flex items-center px-6">
              <button className="text-[15px] font-bold text-[#333333] group-hover:text-[#ed1b2e] flex items-center h-full border-b-4 border-transparent group-hover:border-[#ed1b2e] transition-all">
                Donate Blood
              </button>
              {/* Dropdown Overlay Placeholder - Implementation based on HTML structure */}
              <div className="invisible group-hover:visible absolute top-full left-1/2 -translate-x-1/2 w-[800px] bg-white shadow-xl border-t border-[#e5e5e5] p-8 grid grid-cols-4 gap-6 opacity-0 group-hover:opacity-100 transition-all duration-200 z-50">
                <div className="space-y-4">
                  <h4 className="font-bold text-[14px] text-[#333] border-b pb-2 uppercase">Manage My Donations</h4>
                  <ul className="text-[13px] space-y-2 font-semibold">
                    <li><a href="/give.html" className="hover:text-[#ed1b2e]">Schedule an Appointment</a></li>
                    <li><a href="/give.html/my-account" className="hover:text-[#ed1b2e]">Manage Existing Appointment</a></li>
                    <li><a href="/donate-blood/rapidpass.html" className="hover:text-[#ed1b2e]">Start RapidPass®</a></li>
                  </ul>
                </div>
                {/* Additional columns as per site structure */}
                <div className="space-y-4">
                  <h4 className="font-bold text-[14px] text-[#333] border-b pb-2 uppercase">How to Donate</h4>
                  <ul className="text-[13px] space-y-2 font-semibold">
                    <li><a href="/give.html" className="hover:text-[#ed1b2e]">Find a Blood Drive</a></li>
                    <li><a href="/eligibility.html" className="hover:text-[#ed1b2e]">Eligibility Requirements</a></li>
                  </ul>
                </div>
              </div>
            </li>
            
            <li className="group relative flex items-center px-6">
              <button className="text-[15px] font-bold text-[#333333] group-hover:text-[#ed1b2e] flex items-center h-full border-b-4 border-transparent group-hover:border-[#ed1b2e] transition-all">
                Hosting a Blood Drive
              </button>
            </li>

            <li className="group relative flex items-center px-6">
              <button className="text-[15px] font-bold text-[#333333] group-hover:text-[#ed1b2e] flex items-center h-full border-b-4 border-transparent group-hover:border-[#ed1b2e] transition-all">
                Biomedical Services
              </button>
            </li>
          </ul>
        </nav>

        {/* Find a Blood Drive Widget */}
        <div className="flex items-center">
          <div className="w-[200px] h-[70px] bg-[#ed1b2e] p-[10px] flex flex-col justify-between shadow-[0_2px_4px_rgba(0,0,0,0.1)]">
            <div className="text-white text-[13px] font-bold leading-tight">Find a Blood Drive</div>
            <div className="flex bg-white items-center h-[30px] rounded-sm overflow-hidden mt-1">
              <input 
                type="text" 
                placeholder="20006" 
                className="w-full px-2 text-[13px] text-[#333] focus:outline-none placeholder:text-[#999]"
              />
              <button className="bg-[#007da5] h-full w-[35px] flex items-center justify-center hover:bg-[#005a77] transition-colors">
                <ChevronRight className="text-white w-5 h-5" />
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Mobile Menu Icon (Only visible on small screens) */}
      <div className="lg:hidden absolute left-4 top-1/2 -translate-y-1/2 flex flex-col space-y-1 z-[1] cursor-pointer p-2">
        <span className="w-6 h-[2px] bg-[#333]"></span>
        <span className="w-6 h-[2px] bg-[#333]"></span>
        <span className="w-6 h-[2px] bg-[#333]"></span>
      </div>
    </header>
  );
};

export default Header;