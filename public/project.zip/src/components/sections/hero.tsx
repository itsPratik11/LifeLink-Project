import React from 'react';
import Image from 'next/image';

const HeroSection = () => {
  return (
    <section className="relative w-full overflow-hidden bg-white">
      {/* Red banner background for the right side - Desktop only */}
      <div 
        className="absolute top-0 right-0 h-[400px] w-1/2 bg-[#ED1B2E] hidden md:block"
        style={{ clipPath: 'polygon(15% 0, 100% 0, 100% 100%, 0% 100%)' }}
      ></div>

      <div className="container relative mx-auto px-[15px] pt-10 md:pt-16 lg:pt-20">
        <div className="flex flex-col md:flex-row items-center md:items-start">
          
          {/* Left Content Column */}
          <div className="w-full md:w-1/2 md:pr-10 z-10 text-center md:text-left">
            <h1 className="text-[36px] md:text-[48px] font-extrabold text-[#333333] leading-[1.1] mb-4 tracking-tight">
              Download the Blood<br />Donor App Today
            </h1>
            <p className="text-[18px] md:text-[22px] text-[#333333] leading-[1.4] max-w-[480px] mb-8 mx-auto md:mx-0 font-normal">
              Schedule blood donations quickly and easily right from the palm of your hand.
            </p>
            
            {/* App Store Buttons - Moved to bottom in mobile, here in desktop */}
            <div className="hidden md:flex flex-row gap-4 mt-auto pt-10 items-center justify-center md:justify-start">
              <a 
                href="https://play.google.com/store/apps/details?id=com.redcross.blooddonor" 
                target="_blank" 
                rel="noopener noreferrer"
                className="transition-opacity hover:opacity-80"
              >
                <img 
                  src="https://www.redcrossblood.org/content/dam/redcrossblood/rcb/app/google-play-badge.png" 
                  alt="Get it on Google Play" 
                  width={160}
                  height={48}
                  className="h-[48px] w-auto"
                />
              </a>
              <a 
                href="https://itunes.apple.com/us/app/blood-donor-american-red-cross/id911543818" 
                target="_blank" 
                rel="noopener noreferrer"
                className="transition-opacity hover:opacity-80"
              >
                <img 
                  src="https://www.redcrossblood.org/content/dam/redcrossblood/rcb/app/apple-store-badge.png" 
                  alt="Download on the App Store" 
                  width={160}
                  height={48}
                  className="h-[48px] w-auto"
                />
              </a>
            </div>
          </div>

          {/* Right Content Column (The Red Section Area) */}
          <div className="w-full md:w-1/2 relative mt-10 md:mt-0 flex flex-col items-center">
            {/* Mobile Background for the red area */}
            <div className="absolute inset-0 bg-[#ED1B2E] md:hidden -mx-[15px]"></div>
            
            <div className="relative z-10 flex flex-col md:flex-row items-center md:items-end justify-center w-full gap-8 py-10 md:py-0">
              
              {/* Phone Mockup */}
              <div className="relative w-[220px] md:w-[260px] drop-shadow-[0_10px_30px_rgba(0,0,0,0.15)] transform md:-translate-y-4">
                <img 
                  src="https://www.redcrossblood.org/content/dam/redcrossblood/rcb/app/hero-iphone-new.png" 
                  alt="Blood Donor App Interface" 
                  width={260}
                  height={520}
                  className="w-full h-auto"
                />
              </div>

              {/* QR Code and Label */}
              <div className="flex flex-col items-center md:items-start text-white mb-6">
                <div className="bg-white p-2 mb-4">
                  <img 
                    src="https://www.redcrossblood.org/content/dam/redcrossblood/rcb/app/app-qr-code.png" 
                    alt="Download App QR Code" 
                    width={130}
                    height={130}
                    className="w-[100px] md:w-[130px] h-auto"
                  />
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-[14px] md:text-[16px] font-bold uppercase tracking-wider">Download the App</span>
                  <svg 
                    width="24" 
                    height="24" 
                    viewBox="0 0 24 24" 
                    fill="none" 
                    stroke="currentColor" 
                    strokeWidth="3" 
                    strokeLinecap="round" 
                    strokeLinejoin="round" 
                    className="text-white transform -rotate-45"
                  >
                    <path d="M5 12h14M12 5l7 7-7 7" />
                  </svg>
                </div>
                
                {/* Visual Arrow decoration from original */}
                <div className="hidden lg:block absolute bottom-[-40px] left-[-40px]">
                   <svg width="60" height="40" viewBox="0 0 60 40" fill="none">
                      <path d="M5 35 C 10 10, 40 10, 55 5" stroke="white" strokeWidth="2" strokeDasharray="4 4" fill="none" />
                      <path d="M50 8 L 56 4 L 52 0" stroke="white" strokeWidth="2" fill="none" />
                   </svg>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Mobile App Store Buttons */}
        <div className="flex flex-row md:hidden gap-4 py-10 items-center justify-center w-full">
          <a 
            href="https://play.google.com/store/apps/details?id=com.redcross.blooddonor" 
            className="transition-opacity hover:opacity-80"
          >
            <img 
              src="https://www.redcrossblood.org/content/dam/redcrossblood/rcb/app/google-play-badge.png" 
              alt="Get it on Google Play" 
              width={140}
              height={42}
              className="h-[42px] w-auto"
            />
          </a>
          <a 
            href="https://itunes.apple.com/us/app/blood-donor-american-red-cross/id911543818" 
            className="transition-opacity hover:opacity-80"
          >
            <img 
              src="https://www.redcrossblood.org/content/dam/redcrossblood/rcb/app/apple-store-badge.png" 
              alt="Download on the App Store" 
              width={140}
              height={42}
              className="h-[42px] w-auto"
            />
          </a>
        </div>
      </div>

      {/* Decorative red square for bottom-right alignment fix sometimes seen in responsive */}
      <div className="md:hidden w-full h-2 bg-[#ED1B2E]"></div>
    </section>
  );
};

export default HeroSection;